const router = require('express').Router();
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const User = require('../modals/User.model');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "./Images");
    },
    filename: function (req, file, cb) {
        cb(null, uuidv4() + '-' + Date.now() + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedFileTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(null, false);
    }
};

let upload = multer({ storage, fileFilter });

router.post('/submit', upload.single('image'), (req, res) => {
    try {
        const name = req.body.name;
        const image = req.file.filename;
        

        const newUserData = {
            name,
            image
        };

        const newUser = new User(newUserData);

        newUser.save()
            .then(() => res.json('User Added'))
            // console.log(global.image)
            .catch(err => res.status(400).json('Error: ' + err));
    } catch (error) {
        console.error(error);
        res.status(500).json('Internal Server Error');
    }
});

router.post('/display', async (req, res) => {
    try {
        const users = await User.find({});
        res.json(users);
    } catch (error) {
        console.error(error);
        res.status(500).json('Internal Server Error');
    }
});

// router.post('/display', async(req, res) => {
//     try {
//       res.send([global.image])
//       // console.log(global.image) 
//     //   console.log('no error', global.image)
//       // const register = User.find({});
//       // console.log(register)     
//       // res.json(register);
//     } catch (error) {
//       console.error(error);
//       res.send('Internal Server Error');
//     }
//   });


module.exports = router;


// const router = require('express').Router();
// const multer = require('multer');
// // const images = multer({dest: 'Images/'})
// const { v4: uuidv4 } = require('uuid');
// let path = require('path');
// let User = require('../modals/User.model');

// const storage = multer.diskStorage({
//     destination: function(req, file, cb) {
//         cb(null, "./Images");
//     },
//     filename: function(req, file, cb) {   
//         cb(null, uuidv4() + '-' + Date.now() + path.extname(file.name));
//     }     
// });

// const fileFilter = (req, file, cb) => {
//     const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
//     if(allowedFileTypes.includes(file.mimetype)) {
//         cb(null, true);
//     } else {
//         cb(null, false);
//     }
// }

// let upload = multer({ storage, fileFilter });

// router.post('/submit', upload.single('image'), (req, res) => {
//     const name = req.body.name;
//     const image = req.file.filename;

//     const newUserData = {
//         name,
//         image
//     }
//     path.join(_dirname, 'images');

//     const newUser = new User(newUserData);
//     // console.log("data visible",newUser)

//     newUser.save()
//            .then(() => res.json('User Added'))
//            .catch(err => res.status(400).json('Error: ' + err));
           
// });

// router.post('/display', async(req, res) => {
//     try {
//       res.send([global.image])
//       // console.log(global.image) 
//     //   console.log('no error', global.image)
//       // const register = User.find({});
//       // console.log(register)     
//       // res.json(register);
//     } catch (error) {
//       console.error(error);
//       res.send('Internal Server Error');
//     }
//   });


// module.exports = router;


// const http = require('http');
// const formidable = require('formidable');
// const fs = require('fs');
// const path = require('path');

// const server = http.createServer((req, res) => {
//   if (req.url === '/upload' && req.method.toLowerCase() === 'post') {
//     const form = new formidable.IncomingForm();

//     // Specify the directory where uploaded files will be stored
//     form.uploadDir = path.join(__dirname, 'uploads');

//     form.parse(req, (err, fields, files) => {
//       if (err) {
//         console.error(err);
//         return;
//       }
//       var originalFilename,oldPath;
//       console.log(files)
//       const uploadedFiles = files.file;
      
//       uploadedFiles.forEach((uploadedFile) => {
//       originalFilename= uploadedFile.originalFilename;
//       oldPath=uploadedFile.filepath;
//         console.log(originalFilename);    
//       });
//       const newPath = path.join(form.uploadDir, originalFilename);

//       fs.rename(oldPath, newPath, (err) => {
//         if (err) {
//           console.error(err);
//           return;
//         }

//         res.writeHead(200, { 'Content-Type': 'text/plain' });
//         res.end('File uploaded successfully');
//       });
//     });
//   } else {
//     res.writeHead(200, { 'Content-Type': 'text/html' });
//     res.end(`
//       <form action="/upload" method="post" enctype="multipart/form-data">
//         <input type="file" name="file">
//         <input type="submit" value="Upload File">
//       </form>
//     `);
//   }
// });

// const port = 3000;
// server.listen(port, () => {
//   console.log(`Server is running on http://localhost:${port}`);
// });
