import React ,{useState, useEffect} from 'react'

function AdServices() {
  return (
    <div>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
                <div class="card">
                    <img src="..." class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">rc\components\Admin\AdServices.js
  Line 1:16:  'useState' is defined but never used   no-unused-vars
  Line 1:26:  'useEffect' is defined but never used</p>
                    </div>
                </div>
            </div>
    
        </div>
    </div>
  )
}

export default AdServices