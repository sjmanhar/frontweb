// import React,{ useState} from 'react'


// function User() {
//     const [credential, setcredential]= useState({ name:'',image:'',} );

//     const handleSubmit = async(e)=>{

//         e.preventDefault();
//         console.log(JSON.stringify({name:credential.name, image:credential.image}))
//         const response = await fetch("http://localhost:5000/api/submit",{
//             mode: 'no-cors',
//             method:'POST',
//             headers:{
//                 'Content-Type':'application/json'
//             },
//             body:JSON.stringify({name:credential.name, image:credential.image})
//         });
//         const json = await response.json()
//         alert("i am here")
//         console.log(json);

//         if(!json.success){
//             alert("enter valid credentials")
//         }
//     };
//     const onChange =(event)=>{
//         setcredential({...credential,[event.target.name]:event.target.value})
//     }

//     // const handleSubmit = (e) =>{
//     //     e.preventDefault();
//     //     const formData = new FormData();
//     //     formData.append('name', newUser.name);
//     //     formData.append('photo',newUser.photo);
        

//     //     axios.post('http://localhost:5000/api/submit', formData)
//     //     .then(res => {
//     //         console.log(res);
//     //     })
//     //     .catch(err =>{
//     //         console.log(err);
//     //     });

//     // }


//     // const handleChange = (e) => {
//     //     setcredential({...credential, [e.target.name]: e.target.value});
//     // }

//     // const handlePhoto = (e) => {
//     //     setcredential({...credential, photo: e.target.files[0]});
//     // }
//     return (
       
//         <form onSubmit={handleSubmit} >
//             <input 
//                 type="text"
//                 placeholder="name"
//                 name="name"
//                 value={credential.name}
//                 onChange={onChange}
//             />
//             <input 
//                 type="file" 
//                 accept=".png, .jpg, .jpeg"
//                 name="photo"
                
//                 onChange={onChange}
//             />

//             <input 
//                 type="submit" 
//             />
            
//         </form>
        
//     );
  
// }


// export default User;


// import React, { useState, useEffect } from 'react';

// function User() {
//     const [credential, setCredential] = useState({ name: '', image: '' });

//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         const formData = new FormData();
//         formData.append('name', credential.name);
//         formData.append('image', credential.image);
//         console.log(credential.image)

//         try {
//             const response = await fetch("http://localhost:5000/api/submit", {
//                 method: 'POST',
//                 body: formData
//             });
//             body:JSON.stringify({name:credential.name, image:credential.image})

//             const json = await response.json();
//             console.log(json);

//             if (!json.success) {
//                 alert("Enter valid credentials");
//             }
//         } catch (error) {
//             console.error("Error submitting file:", error);
//         }
//     };

//     const handleChange = (e) => {
//                 setCredential({...credential, [e.target.name]: e.target.value});
//             }
        
//     const handlePhoto = (e) => {
//                 setCredential({...credential, image: e.target.files[0]});
//             }

//         const [imgData, setImgData] = useState([]);

  
//             const fetchMyImg = async () => {
//               try {
//                 const response = await fetch("http://localhost:5000/api/display" ,{
//                   method:"POST",
//                   headers:{
//                     'Content-Type':'application/json'
//                   },
//                   body: JSON.stringify(),
              
//                 } );
               
//                 if (!response.ok) {
//                   throw new Error('Network response was not ok');
//                 } 
//                 const data = await response.json();
                
          
                
//                  if (Array.isArray(data)) {
//                   const imageData = data[0];
//                   console.log("Data received:", imageData);
//                   setImgData(imageData);
//                 } else {
//                   console.error('Data received is not an array:', data[0]);
//                 }
//               } catch (error) {
//                 console.error('Error during fetch:', error);
//               }
//             };

//             useEffect(() => {
//                 fetchMyImg();
//               }, []);
//     return (
//         <div>
//         <form onSubmit={handleSubmit}>
//             <label>NAME</label>
//             <input
//                 type="text"
//                 placeholder="name"
//                 name="name"
//                 value={credential.name}
//                 onChange={handleChange}
//             />
          
//             <label>IMAGE</label>
//             <input
//                 type="file"
//                 accept=".png, .jpg, .jpeg"
//                 name="image"
//                 onChange={handlePhoto}
//             />

            
//             <input
//                 type="submit"
//             />
//         </form>
//         <div>
//             <h2>image details</h2>
//             <div>
//                 {imgData.length > 0 ?(
//                     imgData.map((user, index) =>(
//                         <tr key={index}>
//                             <td>id: {user._id}</td>
//                             <td>NAME: {user.name}</td>
//                             <td>
//                                 <img src= {`./Images/${user.image}`} style={{width:'100%'}} alt='images'/>
//                             </td>
//                         </tr>
//                     ))
//                 ):(
//                     <div>no image details</div>
//                 )

//                 }
//             </div>
//         </div>
//         </div>
//     );     
// }

// export default User;
// import React, { useState, useEffect } from 'react';

// function User() {
//     const [credential, setCredential] = useState({ name: '', image: '' });
//     const [imgData, setImgData] = useState([]);

//     const handleSubmit = async (e) => {
//         e.preventDefault();
    
//         const formData = new FormData();
//         formData.append('name', credential.name);
//         formData.append('image', credential.image);
    
//         try {
//             const response = await fetch("https://localhost:5000/api/submit", {
//                 method: 'POST',
//                 body: formData
//             });
    
//             if (!response.ok) {
//                 throw new Error(`HTTP error: ${response.status}`);
//             }
    
//             const json = await response.json();
//             console.log(json);
//         } catch (error) {
//             console.error("Error submitting file:", error);
//         }
//     };

//     const handleChange = (e) => {
//         setCredential({ ...credential, [e.target.name]: e.target.value });
//     };

//     const handlePhoto = (e) => {
//         setCredential({ ...credential, image: URL.createObjectURL(e.target.files[0]) });
//     };

//     const fetchMyImg = async () => {
//         try {
//             const response = await fetch("http://localhost:5000/api/display", {
//                 method: "POST",
//                 headers: {
//                     Accept: 'application/json',
//                     'Content-Type': 'application/json',
//                 },
//                 body: JSON.stringify(),
//             });

//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }

//             const data = await response.json();

//             if (Array.isArray(data)) {
//                 const imageData = data[0];
//                 console.log("Data received:", imageData);
//                 setImgData(imageData);
//             } else {
//                 console.error('Data received is not an array:', data[0]);
//             }
//         } catch (error) {
//             console.error('Error during fetch:', error.message);
//         }
//     };

//     useEffect(() => {
//         fetchMyImg();
//     }, []);

//     return (
//         <div>
//             <form onSubmit={handleSubmit} encType="multipart/form-data">
//                 <label>NAME</label>
//                 <input
//                     type="text"
//                     placeholder="name"
//                     name="name"
//                     value={credential.name}
//                     onChange={handleChange}
//                 />

//                 <label>IMAGE</label>
//                 <input
//                     type="file"
//                     accept=".png, .jpg, .jpeg"
//                     name="image"
//                     onChange={handlePhoto}
//                 />

//                 <input
//                     type="submit"
//                 />
//             </form>
//             <div>
//                 <h2>image details</h2>
//                 <div>
//                     {imgData && imgData.length > 0 ? (
//                         imgData.map((user, index) => (
//                             <div key={index}>
//                                 <p>id: {user._id}</p>
//                                 <p>NAME: {user.name}</p>
//                                 <img src={user.image} style={{ width: '100%' }} alt="image" />
//                             </div>
//                         ))
//                     ) : (
//                         <div>no image details</div>
//                     )}
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default User;
import React, { useState, useEffect } from 'react';

function User() {
    const [credential, setCredential] = useState({ name: '', image: '' });
    const [imgData, setImgData] = useState([]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('name', credential.name);
        if (credential.image) {
            formData.append('image', credential.image);
        }

        try {
            const response = await fetch("http://localhost:5000/api/submit", {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error(`HTTP error: ${response.status}`);
            }

            const json = await response.json();
            console.log(json);
            // Optionally, reset form fields after successful submission
            setCredential({ name: '', image: '' });
            
            // Fetch updated image data after submission
            fetchMyImg();
        } catch (error) {
            console.error("Error submitting file:", error);
            // Handle error: display a message to the user
        }
    };

    const handleChange = (e) => {
        setCredential({ ...credential, [e.target.name]: e.target.value });
    };

    const handlePhoto = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            setCredential({ ...credential, image: URL.createObjectURL(e.target.files[0]) });
        }
    };

    const fetchMyImg = async () => {
        try {
            const response = await fetch("http://localhost:5000/api/display", {
                method: "POST",
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();

            if (Array.isArray(data) && data.length > 0) {
                setImgData(data);
            } else {
                console.error('Data received is not a valid array:', data);
            }
        } catch (error) {
            console.error('Error during fetch:', error.message);
        }
    };

    useEffect(() => {
        fetchMyImg();
    }, []);

    return (
        <div>
            <form onSubmit={handleSubmit} encType="multipart/form-data">
                <label>NAME</label>
                <input
                    type="text"
                    placeholder="name"
                    name="name"
                    value={credential.name}
                    onChange={handleChange}
                />

                <label>IMAGE</label>
                <input
                    type="file"
                    accept=".png, .jpg, .jpeg"
                    name="image"
                    onChange={handlePhoto}
                />

                <input type="submit" />
            </form>

            
            <div>
                <h2>Image details</h2>
                <div>
                    {imgData && imgData.length > 0 ? (
                        imgData.map((imageDetail, index) => (
                            <div className='card mt-2 ' key={index} >
                                <td> no.: {index +1}</td>
                                <td>{imageDetail.name}</td>
                                <td>ID: {imageDetail._id}</td>
                                <img src={`http://localhost:5000/api/display/Images/${imageDetail.fieldname}`} style={{height:"10vh"}} alt="..." />
                                
                                
                                
                            </div>
                        ))
                    ) : (
                        <div>No image details</div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default User;
