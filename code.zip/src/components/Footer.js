import React from 'react'

function Footer() {
  return (
    <footer className=' h-200px w-100'>Footer</footer>
  )
}

export default Footer